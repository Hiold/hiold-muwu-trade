var s="assets/ccCoin.d040f1e3.png";export{s as _};
